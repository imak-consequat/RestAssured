package api.tests;

import org.testng.annotations.BeforeMethod;
import org.testng.Assert;
//import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.github.javafaker.Faker;
import api.endpoints.UserEndpoints;
import api.payloads.User;
import io.restassured.response.Response;

public class UserTests {
	
	Faker faker;
	User userPayload;
	String Username;
	
	@BeforeMethod
	public void setupData(){
		faker=new Faker();
		userPayload= new User();
		
		userPayload.setId(faker.idNumber().hashCode());
		userPayload.setUsername(faker.name().username());
		userPayload.setFirstname(faker.name().firstName());
		userPayload.setLastname(faker.name().lastName());
		userPayload.setEmail(faker.internet().emailAddress());
		userPayload.setPassword(faker.internet().password(5,10));
		userPayload.setPhone(faker.phoneNumber().phoneNumber());
		userPayload.setUserStatus(0);
			
	}
	
	@Test(priority=1)
	public void testCreateUserRequest() {
		System.out.println("******* POST Request Start *******");
		Username = this.userPayload.getUsername();
		System.out.println("username:"+Username);
		Response response = UserEndpoints.createUser(userPayload);
		 response.then().log().all();
			
  Assert.assertEquals(response.getStatusCode(), 200);
  System.out.println("******* POST Request End's *******"); 		 
	}

	@Test(priority=2)
	public void testUpdateUserRequest() 
	{
		System.out.println("******* PUT Request Start *******"); 
		//update data using payload
		userPayload.setFirstname(faker.name().firstName());
		userPayload.setLastname(faker.name().lastName());
		userPayload.setEmail(faker.internet().emailAddress());
		//get the username 
		System.out.println("username:"+Username);
		//send request starts
		Response response = UserEndpoints.updateUser(Username, userPayload);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
		System.out.println("******* PUT Request End's *******"); 		 
	}
	
	@Test(priority=3, dependsOnMethods= {"testUpdateUserRequest"})
	public void testGETUserAfterPUTrequest()
	{	
		System.out.println("******* GET Request Start *******"); 
		System.out.println("username:"+Username);
		Response response = UserEndpoints.getUser(Username);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
		System.out.println("******* GET Request End's *******");  
	}
	

	@Test(priority=4)
	public void testDeleteUserRequest()
	{
		System.out.println("******* DELETE Request Start *******"); 
		System.out.println("username:"+Username);
		Response response = UserEndpoints.deleteUser(Username);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
		System.out.println("******* DELETE Request End's *******"); 	 
	}
	
}
