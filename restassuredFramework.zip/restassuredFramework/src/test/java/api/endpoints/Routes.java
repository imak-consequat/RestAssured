package api.endpoints;

public class Routes {
	
	/* Swagger URLs aka Routes :
	POST   = https://petstore.swagger.io/v2/user https://petstore.swagger.io/v2/user
	GET    = https://petstore.swagger.io/v2/user/{username}
	PUT    = https://petstore.swagger.io/v2/user/{username}
	DELETE = https://petstore.swagger.io/v2/user/{username}*/
	
	
	// base URL for pet store : Swagger - API collection
	
	public static String  BASE_URL="https://petstore.swagger.io/v2/";
	
	// user model url's as follows
	//public static String  PATH       = "user/";
	//public static String USERNAME    = "{username}";
	public static String  POST_URL   = BASE_URL+"user";
	public static String  GET_URL    = BASE_URL+"user/{username}";
	public static String  PUT_URL    = BASE_URL+"user/{username}";
	public static String  DELETE_URL = BASE_URL+"user/{username}";
	
	// store model URL's as follows
	
	//

}
